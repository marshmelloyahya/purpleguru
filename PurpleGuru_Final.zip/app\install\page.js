'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import styles from './install.module.css';

export default function InstallPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [formData, setFormData] = useState({
    platformName: 'PurpleGuru',
    domainName: 'https://',
    adminEmail: '',
    dbHost: 'localhost',
    dbPort: '3306',
    dbUser: 'root',
    dbPass: '',
    dbName: 'aura_db',
  });

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleInstall = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/install', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      
      if (!res.ok) throw new Error(data.error || 'Installation failed');
      
      setStep(3); // Success step
      setTimeout(() => router.push('/'), 3000);
    } catch (err) {
      setError(err.message);
    }
    setLoading(false);
  };

  return (
    <div className={styles.installPage}>
      <div className={styles.orb1} /><div className={styles.orb2} />
      
      <div className={styles.installCard}>
        <div className={styles.brand}>✦ PurpleGuru Installer</div>
        
        {step === 1 && (
          <div className="fade-in">
            <h2>Welcome to PurpleGuru</h2>
            <p className={styles.subtext}>Let's set up your platform for hosting. You'll need your MySQL database credentials and basic site information.</p>
            <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 24, padding: 14 }} onClick={() => setStep(2)}>Begin Installation</button>
          </div>
        )}

        {step === 2 && (
          <form onSubmit={handleInstall} className="fade-in">
            <h2 style={{ marginBottom: 24 }}>System Configuration</h2>
            
            <div className={styles.sectionHeader}>1. General Settings</div>
            <div className={styles.grid}>
              <div className="form-group">
                <label className="label">Platform Name</label>
                <input required name="platformName" className="input" value={formData.platformName} onChange={handleChange} />
              </div>
              <div className="form-group">
                <label className="label">Domain URL</label>
                <input required name="domainName" className="input" placeholder="https://yourdomain.com" value={formData.domainName} onChange={handleChange} />
              </div>
            </div>
            <div className="form-group" style={{ marginBottom: 24 }}>
              <label className="label">Admin Email</label>
              <input required type="email" name="adminEmail" className="input" placeholder="admin@domain.com" value={formData.adminEmail} onChange={handleChange} />
            </div>

            <div className={styles.sectionHeader}>2. MySQL Database</div>
            <div className={styles.grid}>
              <div className="form-group">
                <label className="label">Database Host</label>
                <input required name="dbHost" className="input" value={formData.dbHost} onChange={handleChange} />
              </div>
              <div className="form-group">
                <label className="label">Database Name</label>
                <input required name="dbName" className="input" value={formData.dbName} onChange={handleChange} />
              </div>
            </div>
            <div className={styles.grid}>
              <div className="form-group">
                <label className="label">Database User</label>
                <input required name="dbUser" className="input" value={formData.dbUser} onChange={handleChange} />
              </div>
              <div className="form-group">
                <label className="label">Database Password</label>
                <input type="password" name="dbPass" className="input" value={formData.dbPass} onChange={handleChange} />
              </div>
            </div>

            {error && <div className="alert alert-error" style={{ marginTop: 16 }}>{error}</div>}

            <div style={{ display: 'flex', gap: 12, marginTop: 32 }}>
              <button type="button" className="btn btn-secondary" style={{ flex: 1, justifyContent: 'center' }} onClick={() => setStep(1)}>Back</button>
              <button type="submit" disabled={loading} className="btn btn-primary" style={{ flex: 2, justifyContent: 'center' }}>
                {loading ? <><span className="spinner"/> Installing...</> : 'Install Platform'}
              </button>
            </div>
          </form>
        )}

        {step === 3 && (
          <div className="fade-in" style={{ textAlign: 'center', padding: '32px 0' }}>
            <div style={{ fontSize: 64, marginBottom: 16 }}>✅</div>
            <h2>Installation Complete!</h2>
            <p className={styles.subtext}>Your platform has been successfully configured. Redirecting to homepage...</p>
          </div>
        )}
      </div>
    </div>
  );
}
