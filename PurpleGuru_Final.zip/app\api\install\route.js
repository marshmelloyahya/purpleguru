import fs from 'fs';
import path from 'path';
import { getDb } from '@/lib/db';
import { cookies } from 'next/headers';

export async function POST(req) {
  try {
    const { platformName, domainName, adminEmail, dbHost, dbPort, dbUser, dbPass, dbName } = await req.json();

    if (!platformName || !domainName || !adminEmail || !dbHost || !dbUser || !dbName) {
      return Response.json({ error: 'Please fill in all required fields.' }, { status: 400 });
    }

    // 1. Create .env file with MySQL credentials and Platform info
    const envContent = `
# PurpleGuru Configuration
PLATFORM_NAME="${platformName}"
DOMAIN_NAME="${domainName}"
ADMIN_EMAIL="${adminEmail}"

# MySQL Database Infos
DB_CONNECTION=mysql
DB_HOST="${dbHost}"
DB_PORT="${dbPort}"
DB_DATABASE="${dbName}"
DB_USERNAME="${dbUser}"
DB_PASSWORD="${dbPass}"

# Installation Flag
APP_INSTALLED=true
    `.trim();

    const envPath = path.join(process.cwd(), '.env');
    fs.writeFileSync(envPath, envContent);

    // 2. Save Platform info into Settings (SQLite for now until MySQL migration is fully run)
    // Even if switching to MySQL later, storing it in current DB ensures the setup finishes smoothly
    const db = getDb();
    
    // Helper to save setting
    const saveSetting = (key, value) => {
      const exists = db.prepare('SELECT id FROM settings WHERE setting_key = ?').get(key);
      if (exists) {
        db.prepare('UPDATE settings SET setting_value = ? WHERE setting_key = ?').run(value, key);
      } else {
        db.prepare('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)').run(key, value);
      }
    };

    saveSetting('site_name', platformName);
    saveSetting('admin_email', adminEmail);
    saveSetting('app_url', domainName);

    // 3. Set a cookie so the middleware knows we are installed without a server restart
    const cookieStore = await cookies();
    cookieStore.set('aura_installed', '1', { path: '/', maxAge: 60 * 60 * 24 * 365 * 10 }); // 10 years

    return Response.json({ success: true, message: 'Installation configuration saved.' });
  } catch (err) {
    return Response.json({ error: err.message }, { status: 500 });
  }
}
