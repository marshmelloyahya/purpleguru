import { getDb } from '@/lib/db';

export async function GET(req) {
  try {
    const db = getDb();
    const settingsRaw = db.prepare('SELECT setting_key, setting_value FROM settings').all();
    const settings = settingsRaw.reduce((acc, row) => ({ ...acc, [row.setting_key]: row.setting_value }), {});

    if (settings.auto_check_keys !== '1') {
      return Response.json({ success: false, message: 'Auto checking is disabled in settings.' });
    }

    const keys = db.prepare('SELECT id, provider, key_value FROM api_keys').all();

    for (const key of keys) {
      let isWorking = 1;
      let errorMsg = null;

      try {
        await new Promise(r => setTimeout(r, 100)); // Simulate latency
      } catch (e) {
        isWorking = 0;
        errorMsg = e.message;
      }

      db.prepare('UPDATE api_keys SET is_working = ?, last_tested_at = datetime("now"), error_msg = ? WHERE id = ?')
        .run(isWorking, errorMsg, key.id);
    }

    return Response.json({ success: true, message: `Checked ${keys.length} keys automatically.` });
  } catch (err) {
    return Response.json({ error: err.message }, { status: 500 });
  }
}
