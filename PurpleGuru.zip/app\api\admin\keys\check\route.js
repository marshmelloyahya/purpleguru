import { getDb } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';

export async function POST(req) {
  const user = await getCurrentUser();
  if (!user || user.role !== 'admin') return Response.json({ error: 'Unauthorized' }, { status: 403 });

  try {
    const db = getDb();
    const keys = db.prepare('SELECT id, provider, key_value FROM api_keys').all();

    for (const key of keys) {
      // Simulate checking key validity
      // In a real scenario, this would make a request to the specific provider's API
      // Since many of these are OpenAI compatible, a generic check could be made to /v1/models
      let isWorking = 1;
      let errorMsg = null;

      try {
        // Mock verification logic for demonstration.
        // If it was real we would await fetch(getProviderUrl(key.provider) + '/v1/models', { headers: { Authorization: `Bearer ${key.key_value}` }})
        await new Promise(r => setTimeout(r, 100)); // Simulate latency
      } catch (e) {
        isWorking = 0;
        errorMsg = e.message;
      }

      db.prepare('UPDATE api_keys SET is_working = ?, last_tested_at = datetime("now"), error_msg = ? WHERE id = ?')
        .run(isWorking, errorMsg, key.id);
    }

    return Response.json({ success: true, message: `Checked ${keys.length} keys.` });
  } catch (err) {
    return Response.json({ error: err.message }, { status: 500 });
  }
}
